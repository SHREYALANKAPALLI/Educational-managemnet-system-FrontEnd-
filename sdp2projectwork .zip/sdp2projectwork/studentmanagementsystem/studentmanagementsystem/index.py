from django.http import HttpResponse
from django.shortcuts import render

def webpage1(request):
    return render(request, 'index.html')

def webpage2(request):
    return render(request, 'about.html')

def webpage3(request):
    return render(request, 'blog.html')

def webpage4(request):
    return render(request, 'blog-singel.html')

def webpage5(request):
    return render(request, 'contact.html')

def webpage6(request):
    return render(request, 'contact-2.html')

def webpage7(request):
    return render(request, 'courses.html')

def webpage8(request):
    return render(request, 'courses-singel.html')

def webpage9(request):
    return render(request, 'events.html')

def webpage10(request):
    return render(request, 'events-singel.html')

def webpage11(request):
    return render(request, 'index-2.html')

def webpage12(request):
    return render(request, 'index-3.html')

def webpage13(request):
    return render(request, 'index-4.html')

def webpage14(request):
    return render(request, 'shop.html')

def webpage15(request):
    return render(request, 'shop-singel.html')

def webpage16(request):
    return render(request, 'teachers.html')

def webpage17(request):
    return render(request, 'teachers-singel.html')

def register(request):
    return render(request, 'registration.html')

def user_login(request):
    return render(request, 'login.html')