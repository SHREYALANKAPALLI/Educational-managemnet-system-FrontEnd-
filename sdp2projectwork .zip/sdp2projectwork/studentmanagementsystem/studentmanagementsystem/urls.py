"""studentmanagementsystem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
import website
from . import index


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('website.urls')),

    path('index', index.webpage1, name='webpage1'),
    path('about', index.webpage2, name='webpage2'),
    path('blog', index.webpage3, name='webpage3'),
    path('blog-singel', index.webpage4, name='webpage4'),
    path('contact', index.webpage5, name='webpage5'),
    path('contact-2', index.webpage6, name='webpage6'),
    path('courses', index.webpage7, name='webpage7'),
    path('courses-singel', index.webpage8, name='webpage8'),
    path('events', index.webpage9, name='webpage9'),
    path('events-singel', index.webpage10, name='webpage10'),
    path('index-2', index.webpage11, name='webpage11'),
    path('index-3', index.webpage12, name='webpage12'),
    path('index-4', index.webpage13, name='webpage13'),
    path('shop', index.webpage14, name='webpage14'),
    path('shop-singel', index.webpage15, name='webpage15'),
    path('teachers', index.webpage16, name='webpage16'),
    path('teachers-singel', index.webpage17, name='webpage17')
    ]

from django.conf import settings
from django.conf.urls.static import static
if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)



























